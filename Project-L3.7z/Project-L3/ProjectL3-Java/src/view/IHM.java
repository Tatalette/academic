package view;

public interface IHM {
}
