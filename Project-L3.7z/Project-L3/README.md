# Project-L3

## Common error
- Connection.createStatement(): conn is null
  
  $\to$ Install and link JDBC Connector to the project
- Unable to connect to the database

  $\to$ Check if the docker database is up and if the docker env if online, create the container by typing 'docker-compose up' in the './Docket-Project/' file.
  
